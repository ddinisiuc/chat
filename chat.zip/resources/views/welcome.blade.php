@foreach ($data as $item)
    <img width="400px" height="250px" src="{{ $item['source'] }}" alt="item tiыввфв">
@endforeach

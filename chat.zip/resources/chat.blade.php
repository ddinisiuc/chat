@extends('layouts.app')
@section('content')
    <h2>dev brsanchasd</h2>
    <div>data</div>
@endsection
